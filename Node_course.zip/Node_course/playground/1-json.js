
const fs = require('fs')

const dataBuffer = fs.readFileSync('1-json.json')
const dataJSON = dataBuffer.toString()
const data = JSON.parse(dataJSON)

const age = 23
const name = 'Richard'
const race = 'human'

data.age = age
data.name = name
data.race = race

console.log(data.age + " " + data.name + " " + data.race)